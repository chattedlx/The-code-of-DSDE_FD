package src;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String args[]) throws IOException, InterruptedException {
        int MAX_SAME_PROB = 30;
        int MAX_DIFF_PROB = 1;
        int MAX_NODE = 100;
        double f = 1 ;
        double cru = 0.3;
        double crl = 0.1;
        double pro = 4;
        double select = 0.5;
        int dividingLine = MAX_NODE*3 ;
        Problem p1 = new Problem(0, 0, MAX_SAME_PROB, MAX_DIFF_PROB, MAX_NODE, f, cru, crl, pro, select, dividingLine);
        p1.newProblem();
    }
}