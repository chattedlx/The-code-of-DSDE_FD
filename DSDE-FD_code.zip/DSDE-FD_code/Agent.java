package src;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.IntStream;

public class Agent{
    protected boolean isMax;
    protected MailManager[] mailManager;
    protected int agentNo;
    private String agentName;
    protected int population;
    protected double domain_lb, domain_ub;
    protected int bestPos;
    protected double[] velocity;

    protected double[] position;
    protected HashMap<Integer, double[]> inbox;
    private HashMap<Integer, double[]> cons_inbox;

    protected Map<String , ArrayList<Integer>> map = new HashMap<String, ArrayList<Integer>>();

    public double getGbest_val() {
        return gbest_val;
    }

    protected double[] pbest_val;
    protected double gbest_val;

    protected double[] pbest_position;
    protected double gbest_position;
    protected double[] pbestParticleNo;
    protected double gbestParticleNo;

    protected Vector<Integer> neighbors;
    private int parent;
    protected Vector<Integer> child;

    public int getCurrentIter() {
        return currentIter;
    }

    public void setCurrentIter(int currentIter) {
        this.currentIter = currentIter;
    }

    protected int currentIter = 0;

    public int getMaxIteration() {
        return maxIteration;
    }

    private int maxIteration;

    protected ArrayList<Edge> edgelist;
    protected int[][] indexToEdge;
    protected HashMap<Edge, Constraint> constraints;
    protected double[] cons_cost;
    protected double[] globalRootCost;


    double f;

    public void setF(double w) {
        this.f = f;
    }

    public void setCru(double cru) {
        this.cru = cru;
    }

    public void setCrl(double crl) {
        this.crl = crl;
    }

    public void setPro(double pro) {
        this.pro = pro;
    }
    public void setSelect(double select) {
        this.select = select;
    }
    public void setDividingLine(int dividingLine){
        this.dividingLine = dividingLine;
    }

    double cru;
    double crl;
    double pro;
    double select;
    int dividingLine;

    long starttime;

    public MailManager[] getMailManager() {
        return mailManager;
    }

    Agent(MailManager[] mailManager, int AgentNo, Vector<Integer> neighbors, int parent, Vector<Integer> child, int population, double domain_lb, double domain_ub, int maxIteration, boolean ismax, ArrayList<Edge> edgelist, int[][] indexToEdge, HashMap<Edge, Constraint> constraints, double f, double cru, double crl, double pro, double select, int dividingLine)
    {
        this.mailManager = mailManager;
        this.agentNo = AgentNo;
        this.agentName = "Agent-"+this.agentNo;
        this.population = population;
        this.domain_lb = domain_lb;
        this.domain_ub = domain_ub;
        this.velocity = new double[this.population];
        this.position = new double[this.population];
        this.inbox = new HashMap<>();
        this.cons_inbox = new HashMap<>();

        this.pbest_position = new double[this.population];
        this.cons_cost = new double[this.population];
        this.bestPos = 0;
        this.pbestParticleNo = new double[this.population+1];
        Arrays.fill(this.pbestParticleNo, -1);
        this.gbestParticleNo = -1;

        this.neighbors = neighbors;
        this.parent = parent;
        this.child = child;

        this.maxIteration = maxIteration;

        this.edgelist = edgelist;
        this.indexToEdge = indexToEdge;
        this.constraints = constraints;
        this.globalRootCost = new double[this.population];
        this.isMax = ismax;


        if(ismax)
        {
            this.pbest_val = new double[this.population];
            Arrays.fill(this.pbest_val, Double.MIN_VALUE);
            this.gbest_val = Double.MIN_VALUE;

        }
        else {
            this.pbest_val = new double[this.population];
            Arrays.fill(this.pbest_val, Double.MAX_VALUE);
            this.gbest_val = Double.MAX_VALUE;
        }
        this.f = f;
        this.cru = cru;
        this.crl = crl;
        this.pro = pro;
        this.select = select;
        this.dividingLine =dividingLine;
        this.starttime = System.currentTimeMillis();
    }

    public void initValues() {
        for(int i = 0; i< this.population; i++)
        {
            Random r = new Random();
            double randomValue = ((Math.random() * (this.domain_ub - this.domain_lb)) + this.domain_lb);
            assert(randomValue <= this.domain_ub && randomValue >= this.domain_lb);
            this.position[i] = randomValue;
        }
    }

    public double cross(double a, double b, double Pc) {
        double pos = a;
        if (Math.random() < Pc ) {
            pos = b;
        }
        return pos;
    }

    public void updateValues() {
        Random r = new Random();
        int number = this.dividingLine;
        ArrayList<Integer> front_local = new ArrayList<>();
        ArrayList<Integer> front_global= new ArrayList<>();
        ArrayList<Integer> back_local= new ArrayList<>();
        ArrayList<Integer> back_global= new ArrayList<>();
        for (int i = 0; i<map.get("sort").size();i++){
            int temp = map.get("sort").get(i);
            if (i < number){
                if ( i % 2 ==0){
                    front_local.add(temp);
                }
                else {
                    front_global.add(temp);
                }
            }
            else {
                if (i % 2==0){
                    back_local.add(temp);
                }
                else {
                    back_global.add(temp);
                }
            }
        }
        ArrayList<Integer> pop_local = new ArrayList<>();
        ArrayList<Integer> pop_global= new ArrayList<>();
        for (int i=0; i<map.get("sort").size(); i++){
            int temp = map.get("sort").get(i);
            if (i % this.pro ==0){
                pop_local.add(temp);
            }
            else {
                pop_global.add(temp);
            }
        }
        ArrayList<Double> update = new ArrayList<>();
        ArrayList<Double> old = new ArrayList<>();
        double[] to_local = new double[pop_local.size()];
        double[] to_global = new double[pop_global.size()];
        double Pc = cru-crl*(maxIteration-currentIter)/maxIteration;


        for (int i =0; i < pop_local.size(); i++ ){
            double temp = this.position[pop_local.get(i)];
            old.add(temp);
            to_local[i] = temp;

        }
        for (int i =0; i < pop_global.size(); i++ ){
            double temp = this.position[pop_global.get(i)];
            old.add(temp);
            to_global[i] = temp;
        }
        double best = this.position[this.bestPos];

        double front_local_pos = this.position[front_local.get(r.nextInt(front_local.size()))];
        double front_global_pos = this.position[front_global.get(r.nextInt(front_global.size()))];
        double back_local_pos = this.position[back_local.get(r.nextInt(back_local.size()))];
        double back_global_pos = this.position[back_global.get(r.nextInt(back_global.size()))];
        for (int i =0;i<to_local.length;i++)
        {
            double pos = to_local[i];
            double new_pos = pos + f * (best - pos) + f * (front_local_pos - back_local_pos);
            double new_one = cross(pos , new_pos,Pc);
            update.add(new_one);
        }
        for (int i =0;i<to_global.length;i++)
        {
            double pos = to_global[i];
            double new_pos = pos + f * (front_global_pos - pos) + f * (back_global_pos - pos);
            double new_one = cross(pos , new_pos,Pc);
            update.add(new_one);
        }
        update.addAll(old);

        for(int i = 0; i < population; i++) {
            position[i] = update.get(i);
            if(this.position[i] < this.domain_lb)
            {
                this.position[i] = this.domain_lb;
            }
            if(this.position[i] > this.domain_ub){

                this.position[i] = this.domain_ub;
            }
        }
    }

    public void sendValueMessage() throws InterruptedException {
        for(int neigh: neighbors)
        {
            Message valueMsg = new Message(this.agentNo, neigh, 202, this.position);
            this.mailManager[neigh].putMessage(valueMsg);
        }
    }

    public void receiveValueMessage() throws InterruptedException {
        int cnt = 0;
        while (cnt < neighbors.size())
        {
            Message rcvdValueMsg = this.mailManager[this.agentNo].getMessage();
            this.inbox.put(rcvdValueMsg.getSenderId(), rcvdValueMsg.getMsgContent());
            cnt += 1;
        }
    }

    public void calculateCost() {
        double[] consCostList = new double[this.population];
        Arrays.fill(consCostList, 0.0);
        for (int neigh: neighbors)
        {
            Constraint cons = this.constraints.get(edgelist.get(indexToEdge[this.agentNo][neigh]));
            for(int i=0; i<population; i++)
            {
                double cons_calc = cons.getA() * Math.pow(this.position[i], 2) + cons.getB() * this.position[i] + cons.getC() * this.position[i] * this.inbox.get(neigh)[i] + cons.getD() * this.inbox.get(neigh)[i] + cons.getE() * Math.pow(this.inbox.get(neigh)[i], 2) + cons.getF();
                consCostList[i] += cons_calc;
            }
        }
        this.cons_cost = consCostList;
    }

    public void sendCostMessage() throws InterruptedException {
        double[] sumChildCost = new double[this.population];
        Arrays.fill(sumChildCost, 0.0);
        for(int baccha: child)
        {
            for(int i = 0; i < population; i++)
            {
                sumChildCost[i] += this.cons_inbox.get(baccha)[i];
            }
        }
        double[] sumTotalCost = new double[this.population];
        for(int i = 0; i < population; i++)
        {
            sumTotalCost[i] = sumChildCost[i] + this.cons_cost[i];
        }
        int neigh = this.parent;
        Message costMsg = new Message(this.agentNo, neigh, 204, sumTotalCost);
        this.mailManager[neigh].putCostMessage(costMsg);
    }

    public void receiveCostMessage() throws InterruptedException {
        int cnt = 0;
        while (cnt < child.size())
        {
            Message rcvdCostValueMsg = this.mailManager[this.agentNo].getCostMessage();
            this.cons_inbox.put(rcvdCostValueMsg.getSenderId(), rcvdCostValueMsg.getMsgContent());
            cnt += 1;
        }

    }

    public void sumRootChildCost() throws InterruptedException {
        double[] sumChildCost = new double[this.population];
        Arrays.fill(sumChildCost, 0.0);
        for(int baccha: child)
        {
            for(int i = 0; i < population; i++)
            {
                 sumChildCost[i] += this.cons_inbox.get(baccha)[i];
            }

        }
        for(int i = 0; i < population; i++)
        {
            this.globalRootCost[i] = sumChildCost[i] + this.cons_cost[i];
            this.globalRootCost[i] /= 2;
        }
    }

    public static int getIndex(double[] arr, double value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == value) {
                return i;
            }
        }
        return -99999;
    }

    public void setPbestGbest() {
        if(isMax) {}
        else {
            ArrayList<Integer> sort = new ArrayList<>();
            double[] current_copy = new double[this.population];
            System.arraycopy(this.globalRootCost, 0, current_copy, 0, this.population);
            double[] change_current = new double[this.population];
            System.arraycopy(this.globalRootCost, 0, change_current, 0, this.population);
            Arrays.sort(change_current);
            this.gbest_val = change_current[0];
            for (int i =0; i < this.population*this.select; i++) {
                int temp = getIndex(current_copy, change_current[i]);
                if (i==0){
                    bestPos=temp;
                }
                sort.add(temp);
            }
            map.put("sort", sort);
        }
    }

    public void sendPbestGbestpositionMessage() throws InterruptedException {
        for(int baccha: child)
        {
            Message bestMsg = new Message(this.agentNo, baccha, 206, (HashMap) map);
            this.mailManager[baccha].putBestMessage(bestMsg);
        }
    }

    public void receivePbestGbestPositionMessage() throws InterruptedException {

        Message rcvdBestMsg = this.mailManager[this.agentNo].getBestMessage();
        map = rcvdBestMsg.getMsgHContent();
    }

    public void printPositions(int iteration){
        System.out.println("Position of " + this.agentName + " on iteration " + iteration + " = " + Arrays.toString(this.position));
    }

}